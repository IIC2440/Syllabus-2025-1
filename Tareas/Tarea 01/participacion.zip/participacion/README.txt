Dividimos el archivo de participación en 3 para poder subirlos a BigQuery, ya que acepta archivos de máximo 100mb. Lo dividimos usando Pandas.
